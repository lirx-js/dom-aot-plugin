import { ILines, indentLines, linesToString, stringToLinesRaw } from '@lifaon/rx-dom';
import { Node } from 'acorn';
import { full } from 'acorn-walk';
import { generate } from 'astring';
import {
  CallExpression,
  Expression,
  Identifier,
  ImportDeclaration,
  ImportDefaultSpecifier,
  ImportNamespaceSpecifier,
  ImportSpecifier,
  MemberExpression,
  Pattern,
  Property,
  SpreadElement,
  Super,
} from 'estree';
import { polyfillDOM } from './shared/misc/polyfill-dom';
import { readFile } from './shared/misc/read-file';
import {
  fixPropertyDefinition,
  isCallExpression,
  isExpressionStatement,
  isIdentifier,
  isImportDeclaration, isImportDefaultSpecifier,
  isImportSpecifier,
  isLiteral,
  isMemberExpression,
  isMetaProperty,
  isNewExpression,
  isObjectExpression,
  isProgram,
  isProperty, isSpreadElement, isTemplateElement, isTemplateLiteral,
} from './shared/parse/estree';
import { parseEcmaScript } from './shared/parse/parse-ecsmascript';
import { aotTranspileAndMinifyReactiveHTMLAsGenericComponentTemplate } from './reactive-html/transpile/aot-transpile-and-minify-reactive-html-as-generic-component-template';
import {
  IAOTTranspileReactiveHTMLAsGenericComponentTemplateOptions,
  IAOTTranspileReactiveHTMLAsGenericComponentTemplateResult,
} from './reactive-html/transpile/aot-transpile-reactive-html-as-generic-component-template';

/*----------------*/

interface IImportSpecifier {
  imported: string;
  local: string;
}

function createImportDeclaration(
  path: string,
  specifiers: Array<ImportSpecifier | ImportDefaultSpecifier | ImportNamespaceSpecifier> = [],
): ImportDeclaration {
  return {
    type: 'ImportDeclaration',
    specifiers,
    source: {
      type: 'Literal',
      value: path,
      raw: JSON.stringify(path),
    },
  };
}

// function appendSpecifiersToImportDeclaration(
//   node: ImportDeclaration,
//   specifiers: Array<ImportSpecifier | ImportDefaultSpecifier | ImportNamespaceSpecifier>,
// ): ImportDeclaration {
//   node.specifiers.push(...specifiers);
//   return node;
// }

function appendSimpleSpecifierToImportDeclaration(
  node: ImportDeclaration,
  importSpecifier: IImportSpecifier,
): ImportDeclaration {
  const alreadyHasSpecifier: boolean = node.specifiers.some((specifier: ImportSpecifier | ImportDefaultSpecifier | ImportNamespaceSpecifier) => {
    if (isImportSpecifier(specifier)) {
      return (specifier.imported.name === importSpecifier.imported)
        && (specifier.local.name === importSpecifier.local);
    } else {
      throw new Error(`Unsupported specifier`);
    }
  });
  if (!alreadyHasSpecifier) {
    node.specifiers.push(createImportSpecifier(importSpecifier));
  }
  return node;
}

function createImportSpecifier(
  {
    imported,
    local,
  }: IImportSpecifier,
): ImportSpecifier {
  return {
    type: 'ImportSpecifier',
    imported: {
      type: 'Identifier',
      name: imported,
    },
    local: {
      type: 'Identifier',
      name: local,
    },
  };
}

function addImportToProgram(
  ast: Node,
  path: string,
  importSpecifier: IImportSpecifier,
): void {
  let found: boolean = false;
  full(ast, (node: Node) => {
    if (
      isImportDeclaration(node)
      && (node.source.value === path)
    ) {
      found = true;
      appendSimpleSpecifierToImportDeclaration(node, importSpecifier);
    }
  });

  if (!found) {
    if (isProgram(ast)) {
      ast.body = [
        createImportDeclaration(
          path,
          [createImportSpecifier(importSpecifier)],
        ),
        ...ast.body,
      ];
    } else {
      throw new Error(`Expected Program`);
    }
  }
}

/*----------------*/

function convertURLNodeToURL(
  node: Expression | Pattern | Super,
  path: string,
): URL | null {
  if (
    isMemberExpression(node)
    && isIdentifier(node.property)
    && (node.property.name === 'href')
  ) {
    return convertURLNodeToURL(node.object, path);
  } else if (
    isNewExpression(node)
    && isIdentifier(node.callee)
    && (node.callee.name === 'URL')
    && (node.arguments.length === 2)
    && isLiteral(node.arguments[0])
    && (typeof node.arguments[0].value === 'string')
    && isImportMetaURLNode(node.arguments[1])
  ) {
    return new URL(node.arguments[0].value, `file:${path}`);
  } else {
    return null;
  }
}

function convertString$TemplateStringOrSimpleImportedConstantNodeToStringOrURL(
  node: Expression | Pattern | Super,
  path: string,
  rootAST: Node,
): string | URL | null {
  if (
    isLiteral(node)
    && (typeof node.value === 'string')
  ) {
    return node.value;
  } else if (
    isTemplateLiteral(node)
    && (node.quasis.length === 1)
    && isTemplateElement(node.quasis[0])
    && (typeof node.quasis[0].value.cooked === 'string')
  ) {
    return node.quasis[0].value.cooked;
  } else if (
    isIdentifier(node)
  ) {
    let url!: URL | undefined;
    const name: string = node.name;
    full(rootAST, (node: Node) => {
      if (
        isImportDeclaration(node)
        && (node.specifiers.length === 1)
        && isImportDefaultSpecifier(node.specifiers[0])
        && isIdentifier(node.specifiers[0].local)
        && (node.specifiers[0].local.name === name)
      ) {
        url = new URL(String(node.source.value), `file:${path}`);
      }
    });

    if (url === void 0) {
      throw new Error(`Unable to locale import for '${ name }'`);
    } else {
      return url;
    }
  } else {
    return null;
  }
}

/*----------------*/

/** REACTIVE HTML **/


/* LOAD */

export interface IAOTLoadTranspileAndMinifyReactiveHTMLAsGenericComponentTemplateOptions extends Omit<IAOTTranspileReactiveHTMLAsGenericComponentTemplateOptions, 'html'> {
  path: string;
}

export function aotLoadTranspileAndMinifyReactiveHTMLAsGenericComponentTemplate(
  {
    path,
    ...options
  }: IAOTLoadTranspileAndMinifyReactiveHTMLAsGenericComponentTemplateOptions,
): Promise<IAOTTranspileReactiveHTMLAsGenericComponentTemplateResult> {
  return readFile(path)
    .then((html: string): IAOTTranspileReactiveHTMLAsGenericComponentTemplateResult => {
      return aotTranspileAndMinifyReactiveHTMLAsGenericComponentTemplate({
        html,
        ...options,
      });
    });
}

/*----------------*/

export function isImportMetaURLNode(
  node: any,
): node is MemberExpression {
  return isMemberExpression(node)
    && isMetaProperty(node.object)
    && isIdentifier(node.object.meta)
    && (node.object.meta.name === 'import')
    && isIdentifier(node.object.property)
    && (node.object.property.name === 'meta')
    && isIdentifier(node.property)
    && (node.property.name === 'url')
    ;
}

function analyseURLProperty(
  node: Property,
  path: string,
): URL {
  const result = convertURLNodeToURL(node.value, path);
  if (result === null) {
    console.log(node);
    throw new Error(`Invalid URL format`);
  } else {
    return result;
  }
}

function analyseHTMLProperty(
  node: Property,
  path: string,
  rootAST: Node,
): string | URL {
  const result = convertString$TemplateStringOrSimpleImportedConstantNodeToStringOrURL(node.value, path, rootAST);
  if (result === null) {
    console.log(node);
    throw new Error(`Unoptimizable html property`);
  } else {
    return result;
  }
}

function analyseCustomElementsPropertyValue(
  node: Expression | Pattern,
): ILines {
  return stringToLinesRaw(generate(node));
}

function analyseCustomElementsProperty(
  node: Property,
): ILines {
  return analyseCustomElementsPropertyValue(node.value);
}

function analyseModifiersPropertyValue(
  node: Expression | Pattern,
): ILines {
  return stringToLinesRaw(generate(node));
}

function analyseModifiersProperty(
  node: Property,
): ILines {
  return analyseModifiersPropertyValue(node.value);
}

/*----*/

export interface IExtractCompileOrLoadReactiveHTMLAsGenericComponentTemplatePropertiesOptions {
  properties: Array<Property | SpreadElement>;
  path: string;
  rootAST: Node;
}

export interface IExtractCompileOrLoadReactiveHTMLAsGenericComponentTemplatePropertiesResult {
  html: string | URL | undefined;
  customElements: ILines | undefined;
  modifiers: ILines | undefined;
}

export function extractCompileOrLoadReactiveHTMLAsGenericComponentTemplateProperties(
  {
    properties,
    path,
    rootAST,
  }: IExtractCompileOrLoadReactiveHTMLAsGenericComponentTemplatePropertiesOptions,
): IExtractCompileOrLoadReactiveHTMLAsGenericComponentTemplatePropertiesResult {
  let html: string | URL | undefined;
  let customElements: ILines | undefined;
  let modifiers: ILines | undefined;

  for (let i = 0, l = properties.length; i < l; i++) {
    const property: (Property | SpreadElement) = properties[i];
    if (
      isProperty(property)
      && isIdentifier(property.key)
    ) {
      switch (property.key.name) {
        case 'url':
          html = analyseURLProperty(property, path);
          break;
        case 'html':
          html = analyseHTMLProperty(property, path, rootAST);
          break;
        case 'customElements':
          customElements = analyseCustomElementsProperty(property);
          break;
        case 'modifiers':
          modifiers = analyseModifiersProperty(property);
          break;
        default:
          throw new Error(`Unexpected property: ${property.key}`);
      }
    } else {
      throw new Error(`Unsupported spread element`);
    }
  }

  return {
    html,
    customElements,
    modifiers,
  };
}

export interface IExtractCompileOrLoadReactiveHTMLAsGenericComponentTemplateCallExpressionPropertiesOptions extends Omit<IExtractCompileOrLoadReactiveHTMLAsGenericComponentTemplatePropertiesOptions, 'properties'> {
  node: CallExpression,
}

export function extractCompileOrLoadReactiveHTMLAsGenericComponentTemplateCallExpressionProperties(
  {
    node,
    ...options
  }: IExtractCompileOrLoadReactiveHTMLAsGenericComponentTemplateCallExpressionPropertiesOptions,
): IExtractCompileOrLoadReactiveHTMLAsGenericComponentTemplatePropertiesResult {
  if (
    (node.arguments.length === 1)
    && isObjectExpression(node.arguments[0])
  ) {
    return extractCompileOrLoadReactiveHTMLAsGenericComponentTemplateProperties({
      properties: node.arguments[0].properties,
      ...options,
    });
  } else {
    throw new Error(`Malformed function call. Only one object argument was expected.`);
  }
}

export interface IAnalyseCompileOrLoadReactiveHTMLAsGenericComponentTemplateCallExpressionOptions extends IExtractCompileOrLoadReactiveHTMLAsGenericComponentTemplateCallExpressionPropertiesOptions {
  wrapWithPromise: boolean,
}

async function analyseCompileOrLoadReactiveHTMLAsGenericComponentTemplateCallExpression(
  {
    node,
    rootAST,
    wrapWithPromise,
    ...options
  }: IAnalyseCompileOrLoadReactiveHTMLAsGenericComponentTemplateCallExpressionOptions,
): Promise<void> {
  // console.log(node);

  const {
    html,
    ...customElementsAndModifiersOptions
  } = extractCompileOrLoadReactiveHTMLAsGenericComponentTemplateCallExpressionProperties({
    node,
    rootAST,
    ...options,
  });

  if (html === void 0) {
    throw new Error(`Missing property 'url' or 'html'`);
  } else {
    const transpiled: IAOTTranspileReactiveHTMLAsGenericComponentTemplateResult = (typeof html === 'string')
      ? aotTranspileAndMinifyReactiveHTMLAsGenericComponentTemplate({
        html,
        ...customElementsAndModifiersOptions,
      })
      : await aotLoadTranspileAndMinifyReactiveHTMLAsGenericComponentTemplate({
        path: html.pathname,
        ...customElementsAndModifiersOptions,
      });

    const [lines, constantsToImport] = transpiled;

    const _lines: ILines = wrapWithPromise
      ? [
        `Promise.resolve(`,
        ...indentLines(lines),
        `)`,
      ]
      : lines;

    const childAST: Node = parseEcmaScript(linesToString(_lines));

    if (
      isProgram(childAST)
      && (childAST.body.length === 1)
      && isExpressionStatement(childAST.body[0])
    ) {
      Object.assign(node, childAST.body[0].expression);

      const iterator: Iterator<[string, string]> = constantsToImport.entries();
      let result: IteratorResult<[string, string]>;
      while (!(result = iterator.next()).done) {
        const [imported, local] = result.value;
        addImportToProgram(
          rootAST,
          '@lifaon/rx-dom',
          {
            imported,
            local,
          },
        );
      }
    } else {
      console.log(childAST);
      throw new Error(`Invalid tree`);
    }
  }
}


/*----------------*/

/** REACTIVE CSS **/

function analyseLoadReactiveCSSAsHTMLStyleElementFirstArgument(
  node: Expression,
  path: string,
  rootAST: Node,
): string | URL {
  const result = convertURLNodeToURL(node, path);
  if (result === null) {
    const result = convertString$TemplateStringOrSimpleImportedConstantNodeToStringOrURL(node, path, rootAST);
    if (result === null) {
      console.log(node);
      throw new Error(`Unoptimizable argument`);
    } else {
      return result;
    }
  } else {
    return result;
  }
}

/*----*/

export function extractCompileOrLoadReactiveCSSAsHTMLStyleElementCallExpressionProperties(
  {
    node,
    ...options
  }: IExtractCompileOrLoadReactiveHTMLAsGenericComponentTemplateCallExpressionPropertiesOptions,
): string | URL {
  if (
    (node.arguments.length === 1)
    && !isSpreadElement(node.arguments[0])
  ) {
    return analyseLoadReactiveCSSAsHTMLStyleElementFirstArgument(
      node.arguments[0],
      options.path,
      options.rootAST,
    );
  } else {
    throw new Error(`Malformed function call. Only one argument was expected.`);
  }
}

async function analyseCompileOrLoadReactiveCSSAsHTMLStyleElementCallExpression(
  {
    node,
    rootAST,
    wrapWithPromise,
    ...options
  }: IAnalyseCompileOrLoadReactiveHTMLAsGenericComponentTemplateCallExpressionOptions,
): Promise<void> {
  console.log(node);

  const css = extractCompileOrLoadReactiveCSSAsHTMLStyleElementCallExpressionProperties({
    node,
    rootAST,
    ...options,
  });

  console.log(css);


  // const lines: IAOTTranspileReactiveHTMLAsGenericComponentTemplateResult = (typeof css === 'string')
  //   ? aotTranspileAndMinifyReactiveHTMLAsGenericComponentTemplate({
  //     html,
  //     ...customElementsAndModifiersOptions,
  //   })
  //   : await aotLoadTranspileAndMinifyReactiveHTMLAsGenericComponentTemplate({
  //     path: html.pathname,
  //     ...customElementsAndModifiersOptions,
  //   });

  const lines: ILines = [];

  const _lines: ILines = wrapWithPromise
    ? [
      `Promise.resolve(`,
      ...indentLines(lines),
      `)`,
    ]
    : lines;

  const childAST: Node = parseEcmaScript(linesToString(_lines));

  if (
    isProgram(childAST)
    && (childAST.body.length === 1)
    && isExpressionStatement(childAST.body[0])
  ) {
    Object.assign(node, childAST.body[0].expression);
  } else {
    console.log(childAST);
    throw new Error(`Invalid tree`);
  }
}



/*----------------*/

/*
  TODO
  - migrate and export reactive html as module
  - ex: cache into and import from @lifaon/rx-dom-aot-plugin/cache/
 */

/*----------------*/

async function runAOT(
  src: string,
  path: string,
): Promise<string> {
  await polyfillDOM();

  const rootAST: Node = parseEcmaScript(src);

  // console.log(rootAST);

  const promises: Promise<void>[] = [];

  fixPropertyDefinition(rootAST);

  full(rootAST, (node: Node) => {
    // if (isImportSpecifier(node)) {
    //   console.log(node);
    // }
    if (
      isCallExpression(node)
      && isIdentifier(node.callee)
    ) {
      const functionName: string = node.callee.name;
      switch (functionName) {
        case 'compileReactiveHTMLAsGenericComponentTemplate':
        case 'loadReactiveHTMLAsGenericComponentTemplate':
          promises.push(
            analyseCompileOrLoadReactiveHTMLAsGenericComponentTemplateCallExpression({
              node,
              path,
              rootAST,
              wrapWithPromise: (functionName === 'loadReactiveHTMLAsGenericComponentTemplate'),
            })
              .catch((error: Error) => {
                console.warn(
                  `Failed to optimize '${functionName}' from file '${path}': ${error.message}`,
                );
              }),
          );
          break;
        // case 'compileReactiveCSSAsComponentStyle':
        // case 'loadAndCompileReactiveCSSAsComponentStyle':
        //   promises.push(
        //     analyseCompileOrLoadReactiveCSSAsHTMLStyleElementCallExpression({
        //       node,
        //       path,
        //       rootAST,
        //       wrapWithPromise: (functionName === 'loadAndCompileReactiveCSSAsComponentStyle'),
        //     })
        //       .catch((error: Error) => {
        //         console.warn(
        //           `Failed to optimize '${functionName}' from file '${path}': ${error.message}`,
        //         );
        //       }),
        //   );
        //   break;
      }
    }
  });

  await Promise.all(promises);

  // console.log(generate(rootAST));

  // return generate(rootAST);
  try {
    return generate(rootAST);
  } catch(e) {
    console.log('---->', src);
    throw e;
  }
}

export function aotPlugin(): any {
  return {
    name: 'aot',

    transform: async (
      src: string,
      path: string,
    ): Promise<any> => {
      if (path.endsWith('.ts')) {
        return {
          code: await runAOT(src, path),
          map: null,
        };
      }
    },
  };
}

