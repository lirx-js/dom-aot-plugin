
// https://github.com/clean-css/clean-css
// https://github.com/postcss/postcss
// https://vitejs.dev/guide/features.html#postcss
export function minifyCSS(
  code: string,
): string {
  return code;
}
